import subprocess
import sys
import time


print("Welcome to the library install wizzard!")
print('This wizzard will automatically install all the requiered libraries that are needed for the project, for you')
print('the prompts closes automatically in 10 seconds when it is done')
print('')
# Function to read library names from a file
def read_libraries_from_file(filename):
    try:
        with open(filename, 'r') as file:
            libraries = file.read().splitlines()
        return libraries
    except FileNotFoundError:
        print(f"File '{filename}' not found.")
        return []

def install_libraries_from_file(filename):
    # Read library names from the file
    libraries = read_libraries_from_file(filename)

    if not libraries:
        print(f"No libraries to install from '{filename}'.")
        return  # No libraries to install

    total = len(libraries)
    installed_libraries = []  # List to store installed libraries along with success/failure status
    for i, library in enumerate(libraries, 1):
        try:
            # Use subprocess to run pip install command
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', library], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            installed_libraries.append(f'Success: {library}')  # Add the success message to the list
        except subprocess.CalledProcessError:
            installed_libraries.append(f'Failed: {library}')  # Add the failure message to the list
        except Exception as e:
            installed_libraries.append(f'Error: {library} ({e})')  # Add an error message to the list if an exception occurs
        
        progress_bar(i, total, prefix='Installing libraries:', suffix=library)  # Display the library name
    
    # List the installed libraries with success/failure status after all installations
    print("")
    print("\nInstalled libraries:")
    for entry in installed_libraries:
        print(entry)

def progress_bar(iteration, total, prefix='', suffix='', length=50, fill='#'):
    percent = int(100 * (iteration / float(total)))
    filled_length = int(length * iteration // total)
    bar = fill * filled_length + '-' * (length - filled_length)
    sys.stdout.write(f'\r{prefix} |{bar}| {percent}% {suffix}')
    sys.stdout.flush()

if __name__ == "__main__":
    filename = "libraries.txt"  # Replace with the path to your libraries file
    libraries_to_install = read_libraries_from_file(filename)
    if libraries_to_install:
        print(f"Reading from:'{filename}'...")
        install_libraries_from_file(filename)
        print("\nInstallation completed!")
        time.sleep(2)
        print("All libraries should have been installed and verified, if not then its a problem with the library or the installation")
    else:
        print(f"No libraries to install from '{filename}'.")
time.sleep(2)
print("The wizzard is done and will close the prompt in 10 seconds")
time.sleep(10)
sys.exit()
